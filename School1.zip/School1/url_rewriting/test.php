<?php 
$inn=1;$p='insertion';
?>
<!DOCTYPE html>
<html>
<head>
	<title>test</title>
</head>
<body>
<a href="article?id=<?=($inn); ?>&t=insertion" >article</a>
</body>
</html>