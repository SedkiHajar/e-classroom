<?php 
var_dump($_GET);
?>
<!DOCTYPE html>
<html>
<head>
	<title>url</title>
</head>
<body>
bonjour article <?//=$_GET['id'];?>
</body>
</html>